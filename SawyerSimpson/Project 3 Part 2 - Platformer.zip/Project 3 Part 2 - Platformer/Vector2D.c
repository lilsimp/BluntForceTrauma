// ---------------------------------------------------------------------------
// Project Name		:	Platformer
// File Name	   	:	Vector2D.c
// Author			    :	Sawyer Simpson
// Creation Date	:	2015/03/08
// Purpose			  :	Vector2D functions.
// History			  : 
// ---------------------------------------------------------------------------


#include "Vector2D.h"

#define EPSILON 0.0001

// ---------------------------------------------------------------------------

void Vector2DZero(Vector2D *pResult)
{
  pResult->x = 0;
  pResult->y = 0;
}

// ---------------------------------------------------------------------------

void Vector2DSet(Vector2D *pResult, float x, float y)
{
  pResult->x = x;
  pResult->y = y;
}

// ---------------------------------------------------------------------------

void Vector2DNeg(Vector2D *pResult, Vector2D *pVec0)
{
  pResult->x = pVec0->x * -1.0f;
  pResult->y = pVec0->y * -1.0f;
}

// ---------------------------------------------------------------------------

void Vector2DAdd(Vector2D *pResult, Vector2D *pVec0, Vector2D *pVec1)
{
  pResult->x = pVec0->x + pVec1->x;
  pResult->y = pVec0->y + pVec1->y;
}

// ---------------------------------------------------------------------------

void Vector2DSub(Vector2D *pResult, Vector2D *pVec0, Vector2D *pVec1)
{
  Vector2DScale(pVec1, pVec1, -1.0f);

  Vector2DAdd(pResult, pVec0, pVec1);
}

// ---------------------------------------------------------------------------

void Vector2DNormalize(Vector2D *pResult, Vector2D *pVec0)
{
  float length = Vector2DLength(pVec0);

  Vector2DScale(pResult, pVec0, (1 / length));
}

// ---------------------------------------------------------------------------

void Vector2DScale(Vector2D *pResult, Vector2D *pVec0, float c)
{
  pResult->x = pVec0->x * c;
  pResult->y = pVec0->y * c;
}

// ---------------------------------------------------------------------------

void Vector2DScaleAdd(Vector2D *pResult, Vector2D *pVec0, Vector2D *pVec1, float c)
{
  Vector2DScale(pResult, pVec0, c);

  Vector2DAdd(pResult, pResult, pVec1);
}

// ---------------------------------------------------------------------------

void Vector2DScaleSub(Vector2D *pResult, Vector2D *pVec0, Vector2D *pVec1, float c)
{
  Vector2DScale(pResult, pVec0, c);

  Vector2DSub(pResult, pResult, pVec1);
}

// ---------------------------------------------------------------------------

float Vector2DLength(Vector2D *pVec0)
{
  float length;

  length = Vector2DSquareLength(pVec0);
  length = sqrt(length);

	return length;
}

// ---------------------------------------------------------------------------

float Vector2DSquareLength(Vector2D *pVec0)
{
  float length;

  length = pVec0->x * pVec0->x;
  length += ( pVec0->y * pVec0->y );

	return length;
}

// ---------------------------------------------------------------------------

float Vector2DDistance(Vector2D *pVec0, Vector2D *pVec1)
{
  float length;

  length = Vector2DSquareDistance(pVec0, pVec1);
  length = sqrt(length);

	return length;
}

// ---------------------------------------------------------------------------

float Vector2DSquareDistance(Vector2D *pVec0, Vector2D *pVec1)
{
  float length;

  length = ( pVec0->x - pVec1->x ) * ( pVec0->x - pVec1->x );
  length += ( ( pVec0->y - pVec1->y ) * ( pVec0->y - pVec1->y ) );

	return length;
}

// ---------------------------------------------------------------------------

float Vector2DDotProduct(Vector2D *pVec0, Vector2D *pVec1)
{
  float dot;

  dot = pVec0->x * pVec1->x;
  dot += ( pVec0->y * pVec1->y );

	return dot;
}

// ---------------------------------------------------------------------------

void Vector2DFromAngleDeg(Vector2D *pResult, float angle)
{
  pResult->x = cos(angle);
  pResult->y = sin(angle);
}

// ---------------------------------------------------------------------------

void Vector2DFromAngleRad(Vector2D *pResult, float angle)
{
  angle *= 180.0f;
  angle /= PI;

  Vector2DFromAngleDeg(pResult, angle);
}

// ---------------------------------------------------------------------------
